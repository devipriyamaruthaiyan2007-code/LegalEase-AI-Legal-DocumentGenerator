# LegalEase — AI-Powered Legal Document Generator

## Project title
**LegalEase: AI-Powered Legal Document Generator using Generative AI**

## Methodology
1. Streamlit frontend collects document type, parties, terms and effective date.
2. FastAPI backend validates requests and exposes `/generate`.
3. AI Core first tries a local Ollama model, so no paid API is mandatory.
4. If Ollama is unavailable, a built-in structured template generator still works.
5. TXT, DOCX and PDF export are provided.

## Folder structure
```text
LegalEase/
├── app.py
├── requirements.txt
├── .env.example
├── README.md
├── backend/
│   ├── __init__.py
│   ├── main.py
│   ├── routes.py
│   └── models.py
├── ai_core/
│   ├── __init__.py
│   └── generator.py
└── utils/
    ├── __init__.py
    └── exporters.py
```

## VS Code setup

Windows:
```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
```

Optional local AI:
```powershell
ollama pull llama3.2
ollama serve
```

Terminal 1:
```powershell
uvicorn backend.main:app --reload
```

Terminal 2:
```powershell
streamlit run app.py
```

Open the URL shown by Streamlit, normally `http://localhost:8501`.

LegalEase produces drafts for assistance. Review by a qualified legal professional is recommended before use.
