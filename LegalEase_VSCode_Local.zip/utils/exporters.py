from io import BytesIO
from docx import Document
from docx.shared import Pt
from fpdf import FPDF


def make_txt(text: str) -> bytes:
    return text.encode("utf-8")


def make_docx(text: str, document_type: str) -> bytes:
    doc = Document()
    normal = doc.styles["Normal"]
    normal.font.name = "Times New Roman"
    normal.font.size = Pt(12)

    doc.add_heading(document_type.upper(), level=0)
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("# "):
            continue
        if line.startswith("## "):
            doc.add_heading(line[3:], level=1)
        else:
            doc.add_paragraph(line)

    output = BytesIO()
    doc.save(output)
    return output.getvalue()


def make_pdf(text: str, document_type: str) -> bytes:
    pdf = FPDF()
    pdf.set_auto_page_break(auto=True, margin=15)
    pdf.add_page()
    pdf.set_font("Times", "B", 16)
    pdf.cell(0, 10, document_type.upper(), ln=True, align="C")
    pdf.ln(5)

    pdf.set_font("Times", size=11)
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            pdf.ln(3)
            continue
        if line.startswith("## "):
            pdf.ln(2)
            pdf.set_font("Times", "B", 12)
            pdf.multi_cell(0, 7, line[3:])
            pdf.set_font("Times", size=11)
        elif not line.startswith("# "):
            pdf.multi_cell(0, 6, line)

    pdf.ln(5)
    pdf.set_font("Times", "I", 9)
    pdf.multi_cell(
        0, 5,
        "LegalEase draft. Review by a qualified legal professional is recommended."
    )
    return bytes(pdf.output())
