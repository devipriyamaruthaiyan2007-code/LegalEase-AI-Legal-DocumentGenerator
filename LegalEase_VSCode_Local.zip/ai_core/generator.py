import os
import requests
from dotenv import load_dotenv

load_dotenv()

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3.2")


class LegalDocumentGenerator:
    def generate_document(self, document_type, parties, terms, effective_date):
        try:
            return self._generate_with_ollama(
                document_type, parties, terms, effective_date
            )
        except Exception:
            return self._template_generate(
                document_type, parties, terms, effective_date
            )

    def _generate_with_ollama(self, document_type, parties, terms, effective_date):
        prompt = f"""
You are a legal-document drafting assistant.
Create a clear, structured draft.

Document type: {document_type}
Parties: {parties}
Terms and conditions: {terms}
Effective date: {effective_date}

Requirements:
- Use formal professional language.
- Include a title, parties and effective date.
- Organize clauses with numbered headings.
- Include supplied terms without inventing specific facts.
- Add a signature section.
- End with a clear draft/review notice.
"""
        response = requests.post(
            f"{OLLAMA_URL}/api/generate",
            json={
                "model": OLLAMA_MODEL,
                "prompt": prompt,
                "stream": False,
                "options": {"temperature": 0.2}
            },
            timeout=90,
        )
        response.raise_for_status()
        text = response.json().get("response", "").strip()
        if not text:
            raise RuntimeError("Ollama returned empty output")
        return text

    def _template_generate(self, document_type, parties, terms, effective_date):
        term_list = [
            x.strip()
            for x in terms.replace("\n", ";").split(";")
            if x.strip()
        ]
        clauses = [
            f"{index}. {term}"
            for index, term in enumerate(term_list, start=1)
        ]

        terms_text = "\n".join(clauses) if clauses else (
            "The parties shall comply with the terms agreed between them."
        )

        return f"""# {document_type.upper()}

## 1. PARTIES
{parties}

## 2. EFFECTIVE DATE
This document is effective from {effective_date}.

## 3. PURPOSE
This document records the understanding and terms agreed between the parties identified above.

## 4. TERMS AND CONDITIONS
{terms_text}

## 5. GENERAL PROVISIONS
The parties should review this draft and make any necessary changes required for their specific circumstances and applicable law.

## 6. SIGNATURES
Party 1: ______________________________
Signature: ____________________________
Date: __________________________________

Party 2: ______________________________
Signature: ____________________________
Date: __________________________________

DRAFT — REVIEW BY A QUALIFIED LEGAL PROFESSIONAL RECOMMENDED.
"""
